import { useMemo } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const Circle = ({ value }: { value: number }) => {
  const dash = useMemo(() => {
    const r = 56, c = 2 * Math.PI * r;
    const p = Math.max(0, Math.min(1, value));
    return { c, o: c - c * p };
  }, [value]);
  return (
    <svg viewBox="0 0 140 140" className="h-40 w-40">
      <circle cx="70" cy="70" r="56" fill="none" stroke="hsl(var(--muted))" strokeWidth="12" />
      <circle cx="70" cy="70" r="56" fill="none" stroke="hsl(var(--primary))" strokeWidth="12"
              strokeLinecap="round" strokeDasharray={dash.c} strokeDashoffset={dash.o} />
      <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle" className="text-2xl font-bold">
        {Math.round(value*30)}d
      </text>
    </svg>
  );
};

const Row = ({ label, value, hint }: { label: string; value: string; hint?: string }) => (
  <div className="flex items-start justify-between rounded-xl border p-3">
    <div>
      <div className="text-sm font-medium">{label}</div>
      {hint && <div className="text-xs text-muted-foreground">{hint}</div>}
    </div>
    <div className="text-base font-semibold">{value}</div>
  </div>
);

export default function Progress() {
  const pct30 = 0.23; // exemplo (23% do objetivo de 30 dias)
  return (
    <div className="pb-28 section space-y-6">
      <h1>Progresso</h1>
      <div className="flex items-center justify-center">
        <Circle value={pct30} />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Row label="Dias limpos seguidos" value="7" hint="meta: 30 dias" />
        <Row label="Pausas concluídas" value="12" />
        <Row label="Check-ins semana" value="5/7" hint="meta: 6+" />
        <Row label="Sem uso noturno" value="3 dias" hint="22h–2h" />
      </div>

      <div className="card p-4 space-y-2">
        <h2>Meta da semana</h2>
        <ul className="list-disc pl-5 text-sm">
          <li>6 check-ins</li>
          <li>2 pausas em horários de risco</li>
          <li>Sem celular no quarto</li>
        </ul>
        <Button className="mt-2">Ajustar metas</Button>
      </div>
    </div>
  );
}
