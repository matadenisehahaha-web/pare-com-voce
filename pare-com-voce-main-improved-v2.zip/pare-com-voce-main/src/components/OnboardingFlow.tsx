import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

export const OnboardingFlow = ({ onComplete }:{ onComplete: ()=>void }) => {
  const [step, setStep] = useState(1);
  const [focus, setFocus] = useState("apostas");
  const [goal, setGoal] = useState("30");
  const [risk, setRisk] = useState("22-02");
  const [buddy, setBuddy] = useState("");

  const next = () => setStep(s => Math.min(4, s+1));
  const back = () => setStep(s => Math.max(1, s-1));

  return (
    <div className="min-h-[100dvh] pb-28">
      <div className="section space-y-3">
        <h1>Bem-vindo ao P.A.R.E.</h1>
        <p className="muted">Vamos configurar rapidinho seu app: foco, metas, horários de risco e apoio humano.</p>
      </div>

      {step===1 && (
        <div className="section">
          <div className="card p-4 space-y-4">
            <h2>Qual é seu foco principal?</h2>
            <RadioGroup value={focus} onValueChange={setFocus}>
              {["apostas","pornografia","álcool","tabaco","drogas","tempo de tela"].map(opt => (
                <div key={opt} className="flex items-center space-x-2">
                  <RadioGroupItem id={opt} value={opt} />
                  <Label htmlFor={opt} className="capitalize">{opt}</Label>
                </div>
              ))}
            </RadioGroup>
            <div className="flex justify-between">
              <span className="muted text-sm">Você pode mudar depois.</span>
              <Button onClick={next}>Continuar</Button>
            </div>
          </div>
        </div>
      )}

      {step===2 && (
        <div className="section">
          <div className="card p-4 space-y-4">
            <h2>Quantos dias quer alcançar?</h2>
            <div className="grid grid-cols-4 gap-2">
              {["7","14","30","90"].map(d => (
                <button key={d} onClick={()=>setGoal(d)} className={`rounded-xl border p-3 text-sm ${goal===d?"border-emerald-600 bg-emerald-50 dark:bg-emerald-950":""}`}>{d} dias</button>
              ))}
            </div>
            <div className="flex justify-between">
              <Button variant="outline" onClick={back}>Voltar</Button>
              <Button onClick={next}>Continuar</Button>
            </div>
          </div>
        </div>
      )}

      {step===3 && (
        <div className="section">
          <div className="card p-4 space-y-4">
            <h2>Horários de risco</h2>
            <p className="muted">Em quais horários você sente mais vontade?</p>
            <div className="grid grid-cols-3 gap-2">
              {["22-02","18-22","manhã","madrugada","fim de semana","trabalho"].map(d => (
                <button key={d} onClick={()=>setRisk(d)} className={`rounded-xl border p-3 text-sm ${risk===d?"border-emerald-600 bg-emerald-50 dark:bg-emerald-950":""}`}>{d}</button>
              ))}
            </div>
            <div className="flex justify-between">
              <Button variant="outline" onClick={back}>Voltar</Button>
              <Button onClick={next}>Continuar</Button>
            </div>
          </div>
        </div>
      )}

      {step===4 && (
        <div className="section">
          <div className="card p-4 space-y-4">
            <h2>Buddy (opcional)</h2>
            <p className="muted">Alguém de confiança para apoiar você nos momentos difíceis.</p>
            <Input placeholder="Nome ou contato" value={buddy} onChange={(e)=>setBuddy(e.target.value)} />
            <div className="flex justify-between">
              <Button variant="outline" onClick={back}>Voltar</Button>
              <Button onClick={()=>{ localStorage.setItem("pare_onboarding_completed","true"); onComplete(); }}>Concluir</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
