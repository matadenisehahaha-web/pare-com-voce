import { Home, PauseCircle, NotebookPen, Shield, MessageCircle } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

const Item = ({ to, icon: Icon, label }: { to: string; icon: any; label: string }) => {
  const location = useLocation();
  const active = location.pathname === to;
  return (
    <Link
      to={to}
      className={`flex flex-col items-center justify-center gap-1 px-4 py-2 text-xs transition-colors ${
        active ? "text-emerald-600 dark:text-emerald-400" : "text-muted-foreground"
      }`}
      aria-label={label}
    >
      <Icon className="h-6 w-6" />
      <span>{label}</span>
    </Link>
  );
};

export const BottomNav = () => {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="mx-auto flex max-w-md items-center justify-between px-2">
        <Item to="/" icon={Home} label="Início" />
        <Item to="/checkin" icon={NotebookPen} label="Diário" />
        <Item to="/apoio" icon={MessageCircle} label="Apoio" />
        <Item to="/escudos" icon={Shield} label="Escudos" />
      </div>
    </nav>
  );
};
