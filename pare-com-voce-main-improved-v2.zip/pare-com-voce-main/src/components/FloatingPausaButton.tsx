import { Link } from "react-router-dom";
import { PauseCircle } from "lucide-react";

export const FloatingPausaButton = () => {
  return (
    <Link
      to="/respiracao"
      className="fixed bottom-20 left-1/2 z-50 -translate-x-1/2 rounded-full shadow-lg focus:outline-none focus:ring-2 focus:ring-emerald-500"
      aria-label="Abrir Pausa"
    >
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-600 text-white dark:bg-emerald-500">
        <PauseCircle className="h-9 w-9" />
      </div>
    </Link>
  );
};
