# Design improvements applied
- Added **AppHeader** with theme toggle and brand.
- Implemented **BottomNav** (Home, Diário, Apoio, Escudos) with blurred background.
- Added **FloatingPausaButton** centered above the tab bar for quick access.
- Revamped **Dashboard**: stats cards, "Plano rápido de hoje", quick actions grid.
- Introduced **emerald** calm palette via CSS variables and dark mode tuning.
- Created `src/index.css` with Tailwind layers and CSS variables for shadcn.
- Wired everything into `Index.tsx`.
